# AgenticRocket · 3분 발표 대본

10장에 한국어와 영어를 함께 배치했습니다. 발표는 한국어 또는 영어 중 하나로 진행합니다.

설명 2분 30초 + 실제 데모 30초 = 총 3분. 마지막 장은 전환 멘트 7초와 데모 30초를 포함합니다. 실제 발화 속도에 맞춰 리허설하세요.

## 한국어 발표

### 1. AgenticRocket · 00:00–00:07 (7초)

안녕하세요. AI가 코드를 직접 고치고 검증하는 성능 최적화 솔루션, AgenticRocket입니다.

발표 팁: 제품명 뒤 잠깐 멈추고 다음 장으로 전환한다.

### 2. 바이브코딩으로 쉬워진 제품 개발 · 00:07–00:20 (13초)

바이브코딩 덕분에 아이디어를 프로덕트로 만드는 일이 쉬워졌습니다. 코드를 잘 몰라도 AI와 대화하며 만들 수 있죠. 새로운 프로덕트도 매일 쏟아집니다.

발표 팁: “만드는 일은 쉬워졌다”만 전달하고 길게 설명하지 않는다.

### 3. 성능 최적화도 사용자 경험 · 00:20–00:37 (17초)

그렇다면 차별점은 어디서 만들까요? 우리는 기획, UI, UX를 고민합니다. 그런데 사용자가 기다리는 시간도 UX입니다. 같은 기능이라면, 바로 반응하는 제품을 쓰고 싶지 않을까요? 성능 최적화도 사용자 경험의 일부입니다.

발표 팁: 오른쪽 UX 영역 안의 성능을 짚는다.

### 4. 올바르고 빠르게 작동해야 한다 · 00:37–00:49 (12초)

작동하기만 하면 끝일까요? 이 비둘기도 일단 날아가긴 합니다. 하지만 우리가 원하는 건, 의도한 방식으로 제대로, 그리고 빠르게 움직이는 제품입니다.

발표 팁: 비둘기 그림을 보여주고 청중이 볼 시간을 짧게 준다.

### 5. 성능 개선에는 검증이 필수 · 00:49–01:09 (20초)

빨라졌다는 말에는 검증이 필요합니다. 원본과 수정본을 여러 번 실행하고, 기능이 그대로인지도 확인해야 하죠. 로컬에서 이 작업을 하면 시간이 걸리고, 동시에 하는 다른 작업이 측정에 영향을 줄 수 있습니다. 검증을 외부 환경으로 옮기면, 내 컴퓨터에서는 개발을 계속할 수 있습니다.

발표 팁: 로컬의 자원 경쟁과 외부 실행의 작업 분리를 설명한다. 외부 환경만으로 측정 정확도가 보장된다는 표현은 쓰지 않는다.

### 6. 보안에서 성능 최적화로 · 01:09–01:25 (16초)

보안에는 Strix, Snyk, Semgrep처럼 문제를 찾고 수정을 돕는 서비스들이 있습니다. 그러면 성능 최적화도 에이전트에게 맡길 수 있지 않을까요? 코드 안의 병목을 직접 고치고, 개선 결과까지 받는 겁니다.

발표 팁: 서비스 이름은 한 번에 읽는다. 경쟁 제품이 없다는 주장 대신 성능 최적화의 위임으로 연결한다.

### 7. Daytona로 만든 AgenticRocket · 01:25–01:39 (14초)

그래서 Daytona 위에 AgenticRocket을 만들었습니다. Daytona는 실행 환경을 빠르게 준비하고 코드 실행 도구를 쉽게 연결할 수 있어, 에이전트가 실제로 일할 공간을 구성하기에 적합했습니다.

발표 팁: Daytona의 연결·실행·에이전트 도구 세 항목을 짚고 넘어간다.

### 8. 코드 탐색, 개선안, 수정, 병렬 검증 · 01:39–02:05 (26초)

GPT 같은 에이전트 모델이 코드베이스를 탐색하고, 성능을 개선할 가설을 세운 뒤 소스를 직접 수정합니다. 한 에이전트가 프로젝트의 맥락을 계속 유지합니다. 수정안이 준비되면 Daytona 샌드박스 여러 개를 병렬로 실행합니다. 각 환경 안에서 같은 수정안을 원본과 반복 비교하고, 기능 테스트와 성능 측정으로 개선 여부를 판단합니다.

발표 팁: 왼쪽의 한 에이전트에서 오른쪽의 여러 검증 환경으로 이어지는 흐름을 짚는다.

### 9. 프로젝트를 맡기면 결과를 받는다 · 02:05–02:23 (18초)

사용자는 프로젝트를 등록하고 목표를 정하면 됩니다. 에이전트가 최적화를 진행하고, 실제 수정 코드와 검증 결과를 돌려줍니다. 무엇을 바꿨고 얼마나 달라졌는지 확인한 뒤, 그 변경을 받아들일지 결정할 수 있습니다.

발표 팁: 프로젝트 입력과 수정 코드·검증 결과 두 산출물을 짚는다.

### 10. 실제 데모 · 02:23–03:00 (37초)

이제 실제 데모를 보시겠습니다. QR로 접속하실 수 있습니다. AI가 고친 코드와 검증 결과를 확인해보죠.

발표 팁: 02:23–02:30 전환 멘트. 02:30–03:00 실제 웹 데모: 목표와 프로젝트 → 실제 코드 변경 → 기능 검사와 측정 결과. QR을 스캔하거나 클릭해 https://jungwuk.jungwuk.com 에 접속한다. 숫자는 화면에서 확인되는 실제 결과만 말한다.

## English talk

### 1. AgenticRocket · 00:00–00:07 (7초)

Meet AgenticRocket: an AI performance engineer that changes code and verifies the improvement.

### 2. 바이브코딩으로 쉬워진 제품 개발 · 00:07–00:20 (13초)

Vibe coding makes it easier to turn an idea into a product. You can build by talking to AI, even without deep coding knowledge. New products keep appearing every day.

### 3. 성능 최적화도 사용자 경험 · 00:20–00:37 (17초)

So how does a product stand out? We think about the idea, the interface, and the experience. But waiting is part of that experience, too. When the features are the same, a responsive product feels better. Performance is part of UX.

### 4. 올바르고 빠르게 작동해야 한다 · 00:37–00:49 (12초)

Is working enough? This pigeon does fly, in its own way. What we want is software that behaves as intended, and does it fast.

### 5. 성능 개선에는 검증이 필수 · 00:49–01:09 (20초)

A speedup needs evidence. We have to run the original and modified code repeatedly and check that behavior is preserved. Local tests take time, and other work can interfere with the measurements. Moving verification to a remote environment lets us keep developing on our own machine.

### 6. 보안에서 성능 최적화로 · 01:09–01:25 (16초)

For security, tools such as Strix, Snyk, and Semgrep help find and fix problems. Could we delegate performance optimization to an agent, too? One that changes the slow code and brings back evidence of the improvement?

### 7. Daytona로 만든 AgenticRocket · 01:25–01:39 (14초)

That is why we built AgenticRocket on Daytona. Its fast sandbox setup and agent-friendly execution tools give the AI a practical workspace in which to inspect, change, and run code.

### 8. 코드 탐색, 개선안, 수정, 병렬 검증 · 01:39–02:05 (26초)

An agent model such as GPT explores the codebase, forms an optimization hypothesis, and edits the source. The same agent keeps the project context. Then multiple Daytona sandboxes run in parallel. Within each one, we repeatedly compare the same patch against the original, using tests and measurements to evaluate the improvement.

### 9. 프로젝트를 맡기면 결과를 받는다 · 02:05–02:23 (18초)

Add a project and set a goal. The agent works on the optimization and returns the actual patch and verification results. You can review what changed and how it performed before deciding whether to adopt the change.

### 10. 실제 데모 · 02:23–03:00 (37초)

Let’s see it in action. Scan the QR code to open the demo. We’ll look at the patch and verification results.
